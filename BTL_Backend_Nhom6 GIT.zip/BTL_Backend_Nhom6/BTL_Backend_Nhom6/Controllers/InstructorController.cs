﻿using Microsoft.AspNetCore.Mvc;
using BTL_Backend_Nhom6.Data;
using System.Linq;

namespace BTL_Backend_Nhom6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InstructorController : ControllerBase
    {
        private readonly AppDbContext _context;

        public InstructorController(AppDbContext context)
        {
            _context = context;
        }

        // API này sẽ trả về toàn bộ danh sách Thầy giáo cho Web React
        [HttpGet]
        public IActionResult GetAll()
        {
            var thayGiao = _context.Instructors.ToList();
            return Ok(thayGiao);
        }
    }
}