﻿using Microsoft.AspNetCore.Mvc;
using BTL_Backend_Nhom6.Data;
using BTL_Backend_Nhom6.Models;

namespace BTL_Backend_Nhom6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly AppDbContext _context;
        public VehicleController(AppDbContext context) { _context = context; }

        [HttpGet]
        public IActionResult GetAll() => Ok(_context.Vehicles.ToList());

        [HttpPost]
        public IActionResult Add(Vehicle v)
        {
            _context.Vehicles.Add(v);
            _context.SaveChanges();
            return Ok(v);
        }

        // Cập nhật ODO và tự động báo bảo trì
        [HttpPut("{id}/update-odo")]
        public IActionResult UpdateOdo(int id, double kmAdd)
        {
            var v = _context.Vehicles.Find(id);
            if (v == null) return NotFound();

            v.Odo += kmAdd;
            if (v.Odo > 5000) v.Status = "Maintenance"; // Logic tự động

            _context.SaveChanges();
            return Ok(v);
        }
    }
}