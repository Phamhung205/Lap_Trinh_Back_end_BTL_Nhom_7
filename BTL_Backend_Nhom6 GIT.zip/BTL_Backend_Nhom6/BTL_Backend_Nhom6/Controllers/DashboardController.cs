﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BTL_Backend_Nhom6.Data;
using BTL_Backend_Nhom6.Models;

namespace BTL_Backend_Nhom6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly AppDbContext _context;

        public DashboardController(AppDbContext context)
        {
            _context = context;
        }

        // API: Hệ thống cảnh báo sớm (Alert System) - Yêu cầu đề bài
        // Logic: Tìm học viên sắp thi (7 ngày tới) nhưng chưa đủ Giờ hoặc Km
        [HttpGet("alerts")]
        public IActionResult GetAlerts()
        {
            // Bước 1: Lấy danh sách học viên có lịch thi trong 7 ngày tới
            var upcomingExams = _context.Enrollments
                .Include(e => e.Course)
                .Where(e => e.ExamDate != null && e.ExamDate < DateTime.Now.AddDays(7))
                .ToList(); // Tải dữ liệu về RAM để xử lý logic phức tạp

            // Bước 2: Lọc ra những người Thiếu Giờ hoặc Thiếu Km
            var riskStudents = upcomingExams
                // Sửa lỗi: Đảm bảo e.Course không null trước khi truy cập thuộc tính
                .Where(e => e.Course != null && (e.CurrentHours < e.Course.DurationHours || e.CurrentKm < e.Course.RequiredKm))
                .Select(e => new
                {
                    StudentId = e.StudentId,
                    ExamDate = e.ExamDate,
                    // Hiển thị tiến độ chi tiết (Sử dụng e.Course! để báo cho trình biên dịch biết là không null)
                    ProgressHours = $"{e.CurrentHours}/{e.Course!.DurationHours} giờ",
                    ProgressKm = $"{e.CurrentKm}/{e.Course!.RequiredKm} km",
                    Status = "NGUY CƠ TRƯỢT: Chưa đủ điều kiện thi!",
                    Missing = $"Thiếu: {e.Course!.DurationHours - e.CurrentHours}h hoặc {e.Course!.RequiredKm - e.CurrentKm}km"
                })
                .ToList();

            return Ok(riskStudents);
        }

        // API: Thống kê số liệu tổng quan cho Dashboard
        [HttpGet("stats")]
        public IActionResult GetStats()
        {
            var stats = new
            {
                TotalVehicles = _context.Vehicles.Count(),
                TotalStudents = _context.Users.Count(u => u.Role == "Student"),
                TotalBookings = _context.Bookings.Count(),

                // Sửa lỗi "Dereference of a possibly null reference":
                // Chỉ tính tổng tiền của những Enrollment có Course hợp lệ (không null)
                TotalRevenue = _context.Enrollments
                    .Include(e => e.Course)
                    .Where(e => e.Course != null)
                    .Sum(e => e.Course!.Price)
            };

            return Ok(stats);
        }
    }
}