﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BTL_Backend_Nhom6.Data;
using BTL_Backend_Nhom6.Models;

namespace BTL_Backend_Nhom6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BookingController(AppDbContext context)
        {
            _context = context;
        }

        // API: Đặt lịch thực hành (Core Feature)
        [HttpPost]
        public IActionResult CreateBooking(Booking b)
        {
            // --- 1. CHECK QUOTA: Kiểm tra học viên còn giờ trong gói không? ---
            var enroll = _context.Enrollments
                .Include(e => e.Course) // Kèm thông tin khóa học
                .FirstOrDefault(e => e.StudentId == b.StudentId);

            // Nếu học viên đã đăng ký khóa học, ta cần kiểm tra giới hạn giờ
            if (enroll != null)
            {
                // Kiểm tra an toàn: Nếu khóa học bị null thì báo lỗi data
                if (enroll.Course == null)
                {
                    return BadRequest("Lỗi dữ liệu: Không tìm thấy thông tin khóa học của học viên này.");
                }

                // Tính thời lượng buổi tập định đặt (Giờ)
                int hoursBooked = (int)(b.EndTime - b.StartTime).TotalHours;

                // Logic: Giờ đã học + Giờ định đặt > Tổng giờ cho phép => CHẶN
                if (enroll.CurrentHours + hoursBooked > enroll.Course.DurationHours)
                {
                    return BadRequest($"Bạn đã hết giờ thực hành! (Tổng: {enroll.Course.DurationHours}h - Đã học: {enroll.CurrentHours}h)");
                }

                // Cộng giờ tạm thời (để demo logic tăng tiến độ)
                enroll.CurrentHours += hoursBooked;
            }

            // --- 2. CHECK CONFLICT: Kiểm tra trùng Xe hoặc Giáo viên ---
            // Logic trùng: (StartA < EndB) và (EndA > StartB)
            bool isConflict = _context.Bookings.Any(x =>
                x.Status != "Cancelled" && // Bỏ qua các lịch đã hủy
                (x.VehicleId == b.VehicleId || x.InstructorId == b.InstructorId) && // Trùng Xe HOẶC Trùng Thầy
                x.StartTime < b.EndTime && b.StartTime < x.EndTime // Giao nhau về mặt thời gian
            );

            if (isConflict)
            {
                return BadRequest("Xe hoặc Giáo viên đã bận trong khung giờ này! Vui lòng chọn giờ khác.");
            }

            // --- 3. LƯU VÀO DATABASE ---
            b.Status = "Pending"; // Mặc định là chờ duyệt
            _context.Bookings.Add(b);
            _context.SaveChanges();

            return Ok(new { Message = "Đặt lịch thành công!", BookingId = b.Id });
        }

        // API: Xem lịch sử đặt lịch của học viên
        [HttpGet("my-schedule/{studentId}")]
        public IActionResult GetMySchedule(int studentId)
        {
            var list = _context.Bookings
                .Where(b => b.StudentId == studentId)
                .OrderByDescending(b => b.StartTime)
                .ToList();
            return Ok(list);
        }
    }
}