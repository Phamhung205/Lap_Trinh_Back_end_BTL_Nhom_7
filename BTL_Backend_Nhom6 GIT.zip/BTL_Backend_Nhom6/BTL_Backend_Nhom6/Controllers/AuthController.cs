﻿using BTL_Backend_Nhom6.Data;
using BTL_Backend_Nhom6.Models;
using Microsoft.AspNetCore.Mvc;
using System;

namespace BTL_Backend_Nhom6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        public AuthController(AppDbContext context) { _context = context; }

        [HttpPost("login")]
        public IActionResult Login(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
            if (user == null) return Unauthorized("Sai tài khoản hoặc mật khẩu!");

            // Trả về thông tin user (trong thực tế sẽ trả về JWT Token)
            return Ok(new { Id = user.Id, FullName = user.FullName, Role = user.Role });
        }

        [HttpPost("register")]
        public IActionResult Register(User user)
        {
            if (_context.Users.Any(u => u.Username == user.Username))
                return BadRequest("Tên tài khoản đã tồn tại!");

            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok("Đăng ký thành công!");
        }
    }
}
